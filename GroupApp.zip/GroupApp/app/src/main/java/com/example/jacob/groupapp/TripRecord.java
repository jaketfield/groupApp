package com.example.jacob.groupapp;

/**
 * Created by Ying Xie on 2016-04-12.
 */
public class TripRecord {

    private int id;
    private String category;
    private String vehicleType;
    private String distance;
    private String date;
    private String note;

    public TripRecord(){

    }

    public TripRecord(String category, String vehicleType, String distance, String date, String note) {
        this.category = category;
        this.vehicleType = vehicleType;
        this.distance = distance;
        this.date = date;
        this.note = note;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
