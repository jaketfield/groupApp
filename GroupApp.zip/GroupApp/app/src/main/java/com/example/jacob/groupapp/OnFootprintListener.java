package com.example.jacob.groupapp;

import android.view.View;

/**
 * Created by YingXie on 2016-04-12.
 */
public interface OnFootprintListener {
    void onFootprintHeadlineSelected(long id);

//    void onFootprintAdded(TripRecord record);

    void onFootprintInstructionClicked();

    void onFootprintNewClicked();

    void onBtnClick(View v, TripRecord record);
}
