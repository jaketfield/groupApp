package com.example.jacob.groupapp;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class FootprintInstructionFragment extends Fragment {
    public static final String ARG_ID = "ROWID";
    private Button btn = null;
    OnFootprintListener mCallBack;
    Long id;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View fragmentView = inflater.inflate(R.layout.footprint_instruction_fragment, container, false);
        btn = (Button)fragmentView.findViewById(R.id.footinstruction_back);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mCallBack.onBtnClick(v, null);
            }
        });
        return fragmentView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mCallBack = (OnFootprintListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFootprintListener");
        }
    }
}
