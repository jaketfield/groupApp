package com.example.jacob.groupapp;


import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class FootprintAddNewFragment extends Fragment {

    Button saveButton = null;
    Button backButton = null;
    private OnFootprintListener mCallback;

    public FootprintAddNewFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View fragmentView= inflater.inflate(R.layout.footprint_add_new_fragment, container, false);
        saveButton = (Button)fragmentView.findViewById(R.id.footadd_save);
        backButton = (Button)fragmentView.findViewById(R.id.footadd_back);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TripRecord tripRecord = new TripRecord();
                EditText categoryView = (EditText) fragmentView.findViewById(R.id.footprint_new_category);
                tripRecord.setCategory(categoryView.getText().toString());
                EditText vehicleTypeView = (EditText) fragmentView.findViewById(R.id.footprint_new_vehicle_type);
                tripRecord.setVehicleType(vehicleTypeView.getText().toString());
                EditText distanceView = (EditText) fragmentView.findViewById(R.id.footprint_new_distance);
                tripRecord.setDistance(distanceView.getText().toString());
                EditText dateView = (EditText) fragmentView.findViewById(R.id.footprint_new_date);
                tripRecord.setDate(dateView.getText().toString());
                EditText noteView = (EditText) fragmentView.findViewById(R.id.footprint_new_note);
                tripRecord.setNote(noteView.getText().toString());

                FootprintDbAdapter dbHelper;
                dbHelper = new FootprintDbAdapter(getActivity());
                dbHelper.open();
                dbHelper.createRecord(tripRecord);
                mCallback.onBtnClick(v, tripRecord);
            }

        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallback.onBtnClick(v, null);
            }
        });

        return fragmentView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallback = (OnFootprintListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFootprintListener");
        }
    }

}
