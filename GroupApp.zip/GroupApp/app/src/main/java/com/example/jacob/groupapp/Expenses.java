package com.example.jacob.groupapp;

/**
 * Created by jacob on 4/18/2016.
 */
public class Expenses {

    private int id;
    private String name;
    private String dAmount;
    private String tPercent;
    private String tAmount;
    private String total;
    private String note;
    private String date;

    public Expenses(){

    }

    public Expenses(String name, String dAmount, String tPercent, String tAmount, String total, String note, String date){

    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getDAmount(){
        return dAmount;
    }

    public void setDAmount(String dAmount){
        this.dAmount=dAmount;
    }

    public String getTPercent(){
        return tPercent;
    }

    public void settPercent(String tPercent){
        this.tPercent = tPercent;
    }

    public String getTAmount(){
        return tPercent;
    }

    public void setTAmount(String tAmount){
        this.tAmount=tAmount;
    }

    public String getTotal() { return total;}

    public void setTotal(String total){ this.total=total;}

    public String getNote(){
        return note;
    }

    public void setNote(String note){
        this.note=note;
    }

    public String getDate(){
        return date;
    }

    public void setDate(String date){
        this.date=date;
    }

    public String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
