package com.example.jacob.groupapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;


public class FootprintActivity extends AppCompatActivity implements OnFootprintListener{

    private FootprintDbAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_footprint);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        if (findViewById(R.id.footprint_fragment_container) != null) {
            if (savedInstanceState != null) {
                return;
            }

            dbHelper = new FootprintDbAdapter(this);
            dbHelper.open();
            dbHelper.deleteAllRecords();
            dbHelper.insertSomeRecords();

            FootprintHeadlineFragment headlineFragment = new FootprintHeadlineFragment();
            headlineFragment.setArguments(getIntent().getExtras());
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.footprint_fragment_container
                            , headlineFragment).commit();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_footprint, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }
        switch (id){
            case R.id.action_one:
              go(ExpenseTracker.class);
                break;
            case R.id.action_two:
                go(TimeTrackerMainActivity.class);
                break;
            case R.id.action_three:
                go(FootprintActivity.class);
                break;
            //case R.id.action_four:
                //go(MainActivity4.class);
               //break;
            case R.id.footprint_add:
                onFootprintNewClicked();
                break;
            case R.id.footprint_instruction:
                onFootprintInstructionClicked();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void go(Class c){
        Intent intent = new Intent(this, c);
        startActivity(intent);
    }

    @Override
    public void onFootprintHeadlineSelected(long id) {
        FootprintDetailFragment detailFragment = new FootprintDetailFragment();
        Bundle args=new Bundle();
        args.putLong(FootprintDetailFragment.ARG_ID,id);
        detailFragment.setArguments(args);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.footprint_fragment_container, detailFragment).commit();

    }

    @Override
    public void onBtnClick(View v, TripRecord record){
        if (v.getId() == R.id.footdetail_summary_btn){
            calculateCarbonSummary(record);
            return;
        }

        FootprintHeadlineFragment headlineFragment = new FootprintHeadlineFragment();
        Bundle args = new Bundle();
        headlineFragment.setArguments(args);
        switch (v.getId()){
            case R.id.footdetail_delete:
                dbHelper.deleteRecordsById(record);
                break;
            case R.id.footadd_save:
                dbHelper.createRecord(record);
                break;
            default:
                break;
        }
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.footprint_fragment_container, headlineFragment).commit();
    }

    private void calculateCarbonSummary(TripRecord record){
        findViewById(R.id.footdetail_summary_btn).setVisibility(View.GONE);
        double rate = 0.0002d;
        //dummy
        if (record.getVehicleType().substring(0, 1).compareTo("P") == 0)
        {
            rate = 0.0004d;
        }
        else if (record.getVehicleType().substring(0, 1).compareTo("V") == 0)
        {
            rate = 0.0003d;
        }
        else if (record.getVehicleType().substring(0, 1).compareTo("B") == 0)
        {
            rate = 0.0005d;
        }
        String result = String.format("%.2f",Double.parseDouble(record.getDistance()) * rate);
        TextView textView = (TextView) findViewById(R.id.footdetail_summary);
        textView.setText("Total Footprint = " + result + " tonnes of CO2e");
    }

    @Override
    public void onFootprintNewClicked() {
        FootprintAddNewFragment newFragment=new FootprintAddNewFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.footprint_fragment_container,
                      newFragment).commit();
    }

    @Override
    public void onFootprintInstructionClicked() {
        FootprintInstructionFragment instructionFragment=new FootprintInstructionFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.footprint_fragment_container,
                        instructionFragment).commit();

    }
}
