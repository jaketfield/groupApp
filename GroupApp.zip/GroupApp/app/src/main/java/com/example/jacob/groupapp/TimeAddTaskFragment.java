package com.example.jacob.groupapp;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.jacob.groupapp.R;

/**
 * Created by Chao on 2016-04-09.
 */
public class TimeAddTaskFragment extends Fragment {

    View rootView;
    TimeHeadlineFragment.OnHeadlineSelectedListener bCallback;
    Spinner categorySpinner;
    TimeActivityDbAdapter dbHelper;
    int typePosition=-1;
    String type=null;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        rootView = inflater.inflate(R.layout.time_add_task, container, false);
        setHasOptionsMenu(true);
        final Button submitButton =(Button)rootView.findViewById(R.id.addTaskButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Task task = new Task();

                EditText title=(EditText)rootView.findViewById(R.id.titleEdit);
                task.setTitle(title.getText().toString());
                 //give the string defined in the spinner class
                task.setCategory(type);

                EditText duration = (EditText)rootView.findViewById(R.id.durationEdit);

                task.setDuration(Integer.valueOf(duration.getText().toString()).intValue());



                EditText note = (EditText)rootView.findViewById(R.id.noteEdit);
                task.setNote(note.getText().toString());

                EditText date = (EditText)rootView.findViewById(R.id.dateEdit);
                task.setDate(date.getText().toString());


                dbHelper =new TimeActivityDbAdapter(getActivity());
//                dbHelper.createTask(title.getText().toString(), type, Integer.parseInt(duration.getText().toString()),
//                        note.getText().toString(),date.getText().toString() );

                dbHelper.createTask(task);


               bCallback.onSubmitButtonClicked();
            }
        });

        categorySpinner = (Spinner) rootView.findViewById(R.id.time_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.priority_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        categorySpinner.setAdapter(adapter);
        //categorySpinner.setSelection(position, false);

       //categorySpinner.post(new Runnable() {
          // @Override
          // public void run() {
               categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                   @Override
                   public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    typePosition=   position;
                       switch(typePosition){
                           case 0:
                               type="Low";
                               break;
                           case 1:
                               type="Medium";
                               break;
                           case 2:
                               type="High";
                               break;
                       }
                   }

                   @Override
                   public void onNothingSelected(AdapterView<?> parent) {

                   }
               });
           //}
       //});


        return rootView;

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            bCallback = (TimeHeadlineFragment.OnHeadlineSelectedListener) context;// important
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }
    public void onCreateOptionsMenu(Menu menu,MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.time_activity_fragment_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

//        if (id == R.id.time_avtivity_instruction) {
//            go(TimeIntroductionFragment.class);
//        }


        switch (id) {
            case R.id.time_activity_menu_add:
                bCallback.onAddnewButtonClicked();
                break;

            case R.id.time_activity_instruction:
                bCallback.onGetHelpClicked();
                break;

            case R.id.time_activity_menu_summary:
                bCallback.onSummaryButtonClicked();

                break;        }

        return super.onOptionsItemSelected(item);
    }

}
