package com.example.jacob.groupapp;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.SQLException;

/**
 * Created by Jacob on 4/13/2016.
 */
public class ExpenseTracker_AddFragment extends Fragment {
    private ExpenseTracker_DbAdapter dao;
    private AddFragmentListener addCallback;

    @Override
    public void onAttach(Activity activity) {//???
        super.onAttach(activity);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            addCallback = (AddFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement AddFragmentListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // If activity recreated (such as from screen rotate), restore
        // the previous article selection set by onSaveInstanceState().
        // This is primarily necessary when in the two-pane layout.
        if (savedInstanceState != null) {

        }
        // Inflate the layout for this fragment

        final View expenseTrackerAddView = inflater.inflate(R.layout.expense_tracker_add, container, false);
        Button button10 = (Button) expenseTrackerAddView.findViewById(R.id.tPercent10);
        Button button15 = (Button) expenseTrackerAddView.findViewById(R.id.tPercent15);
        Button button20 = (Button) expenseTrackerAddView.findViewById(R.id.tPercent20);
        Button buttonAdd = (Button) expenseTrackerAddView.findViewById(R.id.add);

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                expenseTrackerAddView.findViewById(R.id.tPercent15).setVisibility(View.GONE);
                expenseTrackerAddView.findViewById(R.id.tPercent20).setVisibility(View.GONE);
                TextView percent = (TextView) expenseTrackerAddView.findViewById(R.id.tPercentage);
                percent.setText("10%");
            }
        });

        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expenseTrackerAddView.findViewById(R.id.tPercent10).setVisibility(View.GONE);

                expenseTrackerAddView.findViewById(R.id.tPercent20).setVisibility(View.GONE);
                TextView percent = (TextView)expenseTrackerAddView.findViewById(R.id.tPercentage);
                percent.setText("15%");
            }
        });

        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expenseTrackerAddView.findViewById(R.id.tPercent10).setVisibility(View.GONE);
                expenseTrackerAddView.findViewById(R.id.tPercent15).setVisibility(View.GONE);

                TextView percent = (TextView)expenseTrackerAddView.findViewById(R.id.tPercentage);
                percent.setText("20%");
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Expenses expense = new Expenses();
                EditText name = (EditText) expenseTrackerAddView.findViewById(R.id.name);
                expense.setName(name.getText().toString());
                EditText dAmount = (EditText) expenseTrackerAddView.findViewById(R.id.dAmount);
                expense.setDAmount(dAmount.getText().toString());
                TextView tPercent = (TextView) expenseTrackerAddView.findViewById(R.id.tPercentage);
                expense.setTAmount(tPercent.getText().toString());
                TextView note = (EditText) expenseTrackerAddView.findViewById(R.id.note);
                expense.setNote(note.getText().toString());
                TextView date = (EditText) expenseTrackerAddView.findViewById(R.id.date);
                expense.setDate(date.getText().toString());
                addActivity(expense.getName(), expense.getDAmount(), expense.getTPercent(), expense.getTAmount(), expense.getTotal(), expense.getNote(), expense.getDate());
            }
        });

        return expenseTrackerAddView;
    }

    public void addActivity(String name, String dAmount, String tPercent, String tAmount, String total, String note, String date) {

        new AsyncTask<String, Void, Long>() {

            @Override
            protected Long doInBackground(String... param) {
                dao = new ExpenseTracker_DbAdapter(getActivity());
                try {
                    dao.reOpen();
                    return dao.insertRecord(param[0], param[1], param[2], param[3], param[4], param[5], param[6]);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return null;
            }

        }.execute(name, dAmount, tPercent, tAmount, note, date);

        addCallback.afterAdd();

    }

    interface AddFragmentListener {
        void afterAdd();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the current article selection in case we need to recreate the fragment
        //outState.putLong(ARG_ID, currentId);
    }

}