package com.example.jacob.groupapp;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.SQLException;

/**
 * Created by Jacob on 4/13/2016.
 */
public class ExpenseTracker_AddFragment extends Fragment {
    private ExpenseTracker_DbAdapter dao;
    private AddFragmentListener addCallback;

    @Override
    public void onAttach(Activity activity) {//???
        super.onAttach(activity);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            addCallback = (AddFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement AddFragmentListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // If activity recreated (such as from screen rotate), restore
        // the previous article selection set by onSaveInstanceState().
        // This is primarily necessary when in the two-pane layout.
        if (savedInstanceState != null) {

        }

        // Inflate the layout for this fragment

        final View expenseTrackerAddView = inflater.inflate(R.layout.expense_tracker_add, container, false);
        Button button = (Button) expenseTrackerAddView.findViewById(R.id.add);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String name = ((EditText)expenseTrackerAddView.findViewById(R.id.name)).getText().toString();
                String dAmount = ((EditText)expenseTrackerAddView.findViewById(R.id.dAmount)).getText().toString();
                String tPercent = ((EditText)expenseTrackerAddView.findViewById(R.id.tPercent)).getText().toString();
                String tAmount = ((EditText)expenseTrackerAddView.findViewById(R.id.tAmount)).getText().toString();
                String note = ((EditText)expenseTrackerAddView.findViewById(R.id.note)).getText().toString();
                String date = ((EditText)expenseTrackerAddView.findViewById(R.id.date)).getText().toString();
                addActivity(name, dAmount, tPercent, tAmount, note, date);
            }
        });

        return expenseTrackerAddView;
    }

    public void addActivity(String name, String dAmount, String tPercent, String tAmount, String note, String date) {

        new AsyncTask<String, Void, Long>() {

            @Override
            protected Long doInBackground(String... param) {
                dao = new ExpenseTracker_DbAdapter(getActivity());
                try {
                    dao.reOpen();
                    return dao.insertRecord(param[0], param[1], param[2], param[3], param[4], param[5]);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return null;
            }

        }.execute(name, dAmount, tPercent, tAmount, note, date);

        addCallback.afterAdd();

    }

    interface AddFragmentListener {
        void afterAdd();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the current article selection in case we need to recreate the fragment
        //outState.putLong(ARG_ID, currentId);
    }

}