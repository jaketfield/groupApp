package com.example.jacob.groupapp;


    /*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.database.Cursor;
import android.support.v4.app.ListFragment;


    import android.app.Activity;
    import android.os.Build;
    import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

/**
 * Created by Ying Xie on 2016-04-12.
 */
public class FootprintHeadlineFragment extends ListFragment {
    OnFootprintListener mCallback;
    private FootprintDbAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int layout = Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ?
                android.R.layout.simple_list_item_activated_1 : android.R.layout.simple_list_item_1;
        displayListView();
    }

    private void displayListView() {
        dbHelper = new FootprintDbAdapter(getActivity());
        dbHelper.open();
        Cursor cursor = dbHelper.fetchAllRecords();

        String[] columns = new String[]{
                dbHelper.KEY_CATEGORY
        };

        int[] to = new int[]{
                R.id.footprint_category
        };

        dataAdapter = new SimpleCursorAdapter(
                getActivity(), R.layout.footprint_headline_fragment,
                cursor,
                columns,
                to,
                0);

        setListAdapter(dataAdapter);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallback = (OnFootprintListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFootprintListener");
        }
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        mCallback.onFootprintHeadlineSelected(id);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getActivity().getMenuInflater().inflate(R.menu.menu_footprint, menu);
        return true;
    }
}
