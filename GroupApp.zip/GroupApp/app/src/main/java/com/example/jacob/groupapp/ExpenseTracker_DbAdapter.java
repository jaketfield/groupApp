package com.example.jacob.groupapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by Jacob on 4/13/2016.
 */
public class ExpenseTracker_DbAdapter {
    //column name public
    public static final String KEY_ID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_DAMOUNT = "dollar_amount";
    public static final String KEY_PERCENT = "tip_percent";
    public static final String KEY_TAMOUNT = "tip_amount";
    public static final String KEY_NOTE = "note";
    public static final String KEY_CREATION_DATE = "creation_date";

    //other constant
    private static final String DB_NAME = "ExpenseTrackerDB";
    private static final int DB_VERSION = 1;
    private static final String SQLITE_TABLE = "Activity";

    private static final String TABLE_CREATE = "CREATE TABLE if not exists " + SQLITE_TABLE + " (" +
            KEY_ID + " integer PRIMARY KEY autoincrement," +
            KEY_NAME + "," +
            KEY_DAMOUNT + "," +
            KEY_PERCENT + "," +
            KEY_TAMOUNT + "," +
            KEY_NOTE + "," +
            KEY_CREATION_DATE + ");";

    //program variable
    private DatabaseHelper dbHelper;
    private SQLiteDatabase dB;

    private static class DatabaseHelper extends SQLiteOpenHelper {
        // Associate a DB with an Activity
        // set DB name, version;
        public DatabaseHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        // execute create table

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(TABLE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SQLITE_TABLE);
            onCreate(sqLiteDatabase);
        }
    }

    //Constructor to pass the context information
    public ExpenseTracker_DbAdapter(Context context) {
        dbHelper = new DatabaseHelper(context);
    }


    public ExpenseTracker_DbAdapter open() throws SQLException {
        dB = dbHelper.getWritableDatabase();//call onCreate
        return this;
    }

    public void reOpen() throws SQLException{
        dB = dbHelper.getReadableDatabase();
    }

    public void close() {
        if (dbHelper != null) dbHelper.close();
    }

    //insert data to table
    public long insertRecord(String name, String dollar_amount, String tip_percentage, String tip_amount, String note, String creationDate) {
        ContentValues record = new ContentValues();
        record.put(KEY_NAME, name);
        record.put(KEY_DAMOUNT, dollar_amount);
        record.put(KEY_PERCENT, tip_percentage);
        record.put(KEY_TAMOUNT, tip_amount);
        record.put(KEY_NOTE, note);
        record.put(KEY_CREATION_DATE, creationDate);
        Log.d("jacob", "debugger: ");
        return dB.insertOrThrow(SQLITE_TABLE, null, record);
    }

    public void insertRecords() {
        insertRecord("Swiss Chalet", "20", "15", "3", "note", "2016-04-01");
        insertRecord("The KEG", "100", "20", "20", "note", "2016-06-08");
        insertRecord("The Grand", "50", "10", "5", "note", "2016-04-02");
    }

    //query all headlines
    public Cursor fetchAllTitles() {
        Cursor cursor = dB.query(SQLITE_TABLE, new String[] {KEY_ID, KEY_NAME}, null, null, null, null, null);
        if(cursor != null) cursor.moveToFirst();
        return cursor;
    }

    public Cursor fetchActivityById(String id) throws SQLException {

        Cursor cursor = (id == null || id.length() == 0) ?
                dB.query(SQLITE_TABLE, new String[] {KEY_ID, KEY_NAME, KEY_DAMOUNT, KEY_PERCENT, KEY_TAMOUNT,
                                KEY_NOTE, KEY_CREATION_DATE},
                        null, null, null, null, null):
                dB.query(true, SQLITE_TABLE, new String[] {KEY_ID, KEY_NAME, KEY_DAMOUNT, KEY_PERCENT, KEY_TAMOUNT,
                        KEY_NOTE, KEY_CREATION_DATE}, KEY_ID + "= '" + id + "'", null, null, null, null, null);
        if(cursor != null) cursor.moveToFirst();
        return cursor;
    }

    public void deleteAll() {
        dB.delete(SQLITE_TABLE, null, null);
    }

}