package com.example.tgk.integrationwithfragment;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Chao on 2016-04-08.
 */
public class TaskDetailsFragment extends Fragment {

    final static String ARG_POSITION = "arowId";
    long arowId = 1;
    private TimeActivityDbAdapter dbHelper;
    TimeHeadlineFragment.OnHeadlineSelectedListener mCallback;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //dbHelper = new ArticlesDbAdapter(getActivity()); //??????
        // If activity recreated (such as from screen rotate), restore
        // the previous article selection set by onSaveInstanceState().
        // This is primarily necessary when in the two-pane layout.
        //if (savedInstanceState != null) {
        //  mCurrentPosition = savedInstanceState.getLong(ARG_POSITION);
        //}
        setHasOptionsMenu(true);
        // Inflate the layout for this fragment
       View view= inflater.inflate(R.layout.time_task_details, container, false);
        Button deleteButton=(Button)view.findViewById(R.id.time_activity_delete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper=new TimeActivityDbAdapter(getActivity());
                dbHelper.open();
                dbHelper.deletTaskById(getArguments().getLong(ARG_POSITION));
                mCallback.onSubmitButtonClicked();
            }
        });
        return view;

    }

    @Override
    public void onStart() {
        super.onStart();

        // During startup, check if there are arguments passed to the fragment.
        // onStart is a good place to do this because the layout has already been
        // applied to the fragment at this point so we can safely call the method
        // below that sets the article text.
        Bundle args = getArguments();
        if (args != null) {
            // Set article based on argument passed in
            updateTaskView(args.getLong(ARG_POSITION));
        } else if (arowId != 1) {
            // Set article based on saved instance state defined during onCreateView
            updateTaskView(arowId);
        }
    }

    public void updateTaskView(long id){
        dbHelper = new TimeActivityDbAdapter(getActivity());//??????
        dbHelper.open(); //!!!!!!!!!!!!!!!
        Cursor cursor = dbHelper.fetchTasksByRowId(id);
        TextView title = (TextView) getActivity().findViewById(R.id.title);
        title.setText(cursor.getString(cursor.getColumnIndexOrThrow("title")));

        TextView category = (TextView) getActivity().findViewById(R.id.category);
        category.setText(cursor.getString(cursor.getColumnIndexOrThrow("category")));

        TextView note = (TextView) getActivity().findViewById(R.id.note);
        note.setText(cursor.getString(cursor.getColumnIndexOrThrow("note")));

        TextView duration = (TextView) getActivity().findViewById(R.id.duration);
        duration.setText(cursor.getString(cursor.getColumnIndexOrThrow("duration")));

        TextView date = (TextView) getActivity().findViewById(R.id.date);
        date.setText(cursor.getString(cursor.getColumnIndexOrThrow("dateCreated")));

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the current article selection in case we need to recreate the fragment
        outState.putLong(ARG_POSITION, arowId);
    }
    public void onCreateOptionsMenu(Menu menu,MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.time_activity_fragment_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

//        if (id == R.id.time_avtivity_instruction) {
//            go(TimeIntroductionFragment.class);
//        }


        switch (id) {
            case R.id.time_activity_menu_add:
                mCallback.onAddnewButtonClicked();
                break;

            case R.id.time_activity_instruction:
                mCallback.onGetHelpClicked();
                break;

            case R.id.time_activity_menu_summary:
                mCallback.onSummaryButtonClicked();

                break;        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            mCallback = (TimeHeadlineFragment.OnHeadlineSelectedListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }
}
