package com.example.tgk.integrationwithfragment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Chao on 2016-04-04.
 */
public class TimeActivityDbAdapter {


    public static final String KEY_ROWID = "_id";
    public static final String KEY_CATEGORY = "category";
    public static final String KEY_TITLE = "title";
    public static final String KEY_DURATION = "duration";
    public static final String KEY_NOTE = "note";
    public static final String KEY_DATECREATED = "dateCreated";

    private static final String TAG = "TimeActivityDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static final String DATABASE_NAME = "TimeTracker";
    private static final String SQLITE_TBALE = "Activities";
    private static final int DATABASE_VERSION = 1;

    private final Context mContext;


    private static final String DATABASE_CREATE = " CREATE TABLE IF NOT EXISTS " + SQLITE_TBALE
            +" ( "+ KEY_ROWID +" integer PRIMARY KEY autoincrement," + KEY_CATEGORY +", "
            + KEY_TITLE + ", "+ KEY_DURATION + ", " + KEY_NOTE + ", " + KEY_DATECREATED+  " );";


    public TimeActivityDbAdapter(Context ctx){
        this.mContext=ctx;
    }



    private static class DatabaseHelper extends SQLiteOpenHelper {


        public DatabaseHelper(Context context) {
            super (context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        @Override

        public void onCreate (SQLiteDatabase db){

            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion){
            db.execSQL("DROP TABLE if exists " + SQLITE_TBALE);
            onCreate(db);
        }
    }

    // act like the initialize the mContext


    public TimeActivityDbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        if (mDbHelper != null){
            mDbHelper.close();
        }
    }

    public long createTask(String category, String title, int duration, String note, String dateCreated){
        ContentValues initialValues = new ContentValues();
        mDbHelper = new DatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        initialValues.put(KEY_CATEGORY, category);
        initialValues.put(KEY_TITLE, title);
        initialValues.put(KEY_DURATION, duration);
        initialValues.put(KEY_NOTE, note);
        initialValues.put(KEY_DATECREATED, dateCreated);

        return mDb.insert(SQLITE_TBALE, null, initialValues); //????
    }

    public long createTask(Task task){
        ContentValues initialValues = new ContentValues();
        mDbHelper = new DatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        initialValues.put(KEY_CATEGORY, task.getCategory());
        initialValues.put(KEY_TITLE,task.getTitle());
        initialValues.put(KEY_DURATION, task.getDuration());
        initialValues.put(KEY_NOTE, task.getNote());
        initialValues.put(KEY_DATECREATED, task.getDate());
        return mDb.insert(SQLITE_TBALE, null, initialValues);
    }

    public boolean deleteAllTasks (){
        int doneDelete = 0;
        doneDelete = mDb.delete(SQLITE_TBALE, null, null);
        Log.w(TAG, Integer.toString(doneDelete));
        return doneDelete >0;
    }
    public boolean deletTaskById(long id) {
        int doneDelete = 0;
        doneDelete = mDb.delete(SQLITE_TBALE, KEY_ROWID+"=?", new String[]{
                String.valueOf(id)
        });
        Log.w(TAG, Integer.toString(doneDelete));
        return doneDelete >0;
    }


    public Cursor fetchTasksByRowId(long id ) throws SQLException{

        Cursor mCursor = null;

        mCursor = mDb.query(true, SQLITE_TBALE, new String[]{KEY_ROWID, KEY_CATEGORY, KEY_TITLE,
                KEY_DURATION, KEY_NOTE, KEY_DATECREATED}, KEY_ROWID + " = ? ",
                new String[]{String.valueOf(id)}, null,null,null,null);

        if(mCursor != null){
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchTaskTitles() {
        Cursor mCursor = mDb.query(SQLITE_TBALE, new String[]{KEY_TITLE},null,null,null,null,null);
        if(mCursor != null){
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor fetchAllTasks(){
        Cursor mCursor =null;
        mCursor = mDb.query(SQLITE_TBALE, new String[]{KEY_ROWID, KEY_CATEGORY, KEY_TITLE,
                KEY_DURATION, KEY_NOTE, KEY_DATECREATED}, null,null,null,null,null);
        if(mCursor != null){
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public void insertTasks(){
        createTask("Medium","COBOL project3",5,"Read the lecture notes, start early","April 3, 2016");
        createTask("High","Android Group Project",10,"Read the lecture notes and sample code," +
                " start early","April 4, 2016");


    }
    public int getTotalTime(String type){
        int total=0;
        Cursor mCursor =null;
        mCursor = mDb.query(SQLITE_TBALE, new String[]{
                KEY_DURATION}, KEY_CATEGORY+"=?",new String[]{type},null,null,null);
        if(mCursor != null){
            mCursor.moveToFirst();
        }
        for(int i=0;i<mCursor.getCount();i++){
            total+=  mCursor.getInt(mCursor.getColumnIndex(KEY_DURATION));
            mCursor.moveToNext();
        }

      return  total;

    }
}
