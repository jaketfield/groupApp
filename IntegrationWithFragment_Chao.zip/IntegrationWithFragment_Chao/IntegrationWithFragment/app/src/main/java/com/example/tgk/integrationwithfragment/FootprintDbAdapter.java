package com.example.tgk.integrationwithfragment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Ying Xie on 2016-04-12.
 */
public class FootprintDbAdapter {

    public final static String KEY_ROWID = "_id";
    public final static String KEY_CATEGORY = "category";
    public final static String KEY_VEHICLETYPE = "vehicleType";
    public final static String KEY_DISTANCE = "distance";
    public final static String KEY_DATE = "date";
    public final static String KEY_NOTE = "note";

    private static final String TAG = "FootprintDBAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static final String DATABASE_NAME = "Carbon Footprint";
    private static final String SQLITE_TABLE = "Trip";
    private static final int DATABASE_VERSION = 1;

    private final Context mCtx;

    private static final String DATABASE_CREATE =
            "CREATE TABLE if not exists " + SQLITE_TABLE + " (" +
                    KEY_ROWID + " integer PRIMARY KEY autoincrement," +
                    KEY_CATEGORY + "," +
                    KEY_VEHICLETYPE +","+
                    KEY_DISTANCE + ","+
                    KEY_DATE + ", " +
                    KEY_NOTE +  ");";

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.w(TAG, DATABASE_CREATE);
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + SQLITE_TABLE);
            onCreate(db);
        }
    }

    public FootprintDbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    public FootprintDbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null) {
            mDbHelper.close();
        }
    }

    public long createRecord(TripRecord tripRecord) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_CATEGORY, tripRecord.getCategory());
        initialValues.put(KEY_VEHICLETYPE, tripRecord.getVehicleType());
        initialValues.put(KEY_DISTANCE, tripRecord.getDistance());
        initialValues.put(KEY_DATE, tripRecord.getDate());
        initialValues.put(KEY_NOTE, tripRecord.getNote());

        return mDb.insert(SQLITE_TABLE, null, initialValues);
    }

    public boolean deleteRecordsById(TripRecord tripRecord){
        int doneDelete = 0;
        doneDelete = mDb.delete(SQLITE_TABLE, KEY_CATEGORY + " like '%" + tripRecord.getCategory() + "%'" , null);
        Log.w(TAG, Integer.toString(doneDelete) + "deleted");
        return doneDelete > 0;
    }

    public boolean deleteAllRecords() {

        int doneDelete = 0;
        doneDelete = mDb.delete(SQLITE_TABLE, null , null);
        Log.w(TAG, Integer.toString(doneDelete));
        return doneDelete > 0;

    }

    public Cursor fetchAllRecords() {

        Cursor cursor = mDb.query(SQLITE_TABLE, new String[] {
                        KEY_ROWID,KEY_CATEGORY, KEY_VEHICLETYPE,
                        KEY_DISTANCE, KEY_DATE, KEY_NOTE},
                null, null, null, null, null);


        if (cursor != null) {
            cursor.moveToFirst();
        }

        return cursor;
    }

    public Cursor fetchRecordById(long id) throws SQLException {
        Log.w(TAG, Long.toString(id));
        Cursor mCursor = null;
        mCursor = mDb.query(true, SQLITE_TABLE, new String[] {
                            KEY_ROWID, KEY_CATEGORY, KEY_VEHICLETYPE, KEY_DISTANCE, KEY_DATE, KEY_NOTE},
                    KEY_ROWID + " = " + id + ";" , null, null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    public Cursor fetchHeadline() {


        Cursor mCursor = null;

        mCursor = mDb.query(SQLITE_TABLE, new String[] {KEY_ROWID,
            KEY_CATEGORY, KEY_VEHICLETYPE, KEY_DISTANCE, KEY_DATE, KEY_DATE},
                 null, null,null, null, null);

        if (mCursor != null) {
         mCursor.moveToFirst();
        }
        return mCursor;
    }


    public void insertSomeRecords() {
        TripRecord tripRecord1 = new TripRecord("Long Vacation", "Plane", "5000", "2016-04-01", "Bring the passport");
        createRecord(tripRecord1);

        TripRecord tripRecord2 = new TripRecord("Short Vacation", "Van", "2800", "2015-07-08", "Make sure change the oil for the car");
        createRecord(tripRecord2);

        TripRecord tripRecord3 = new TripRecord("Camping", "Big Car", "300", "2016-03-09", "Bring the tent");
        createRecord(tripRecord3);

        TripRecord tripRecord4 = new TripRecord("Visiting friend", "Medium Car", "150", "2016-02-07", "Buy some gifts");
        createRecord(tripRecord4);

        TripRecord tripRecord5 = new TripRecord("Long Vacation", "Van", "2000", "2016-04-01", "Bring the passport");
        createRecord(tripRecord5);
    }
}