package com.example.tgk.integrationwithfragment;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;


/**
 * Created by Chao on 2016-04-08.
 */
public class TimeHeadlineFragment extends ListFragment {

    OnHeadlineSelectedListener mCallback;
    View rootView;
    private TimeActivityDbAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;

    // The container Activity must implement this interface so the frag can deliver messages
    public interface OnHeadlineSelectedListener {
        /** Called by HeadlinesFragment when a list item is selected */
        void onTaskSelected(long id);
        void onSubmitButtonClicked();
        void onAddnewButtonClicked();
        void onViewButtonClicked();
        void onBackToListButtonClicked();
        void onDoneButtonClicked();
        void onSummaryButtonClicked();

        void onGetHelpClicked();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setHasOptionsMenu(true);
        // We need to use a different list item layout for devices older than Honeycomb
        int layout = Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ?
                android.R.layout.simple_list_item_activated_1 : android.R.layout.simple_list_item_1;

        //????added line

        dbHelper = new TimeActivityDbAdapter(getActivity()); // use this instead of this, because it must be an activity
        dbHelper.open();
        if(dbHelper.fetchAllTasks().getCount()==0){
         dbHelper.insertTasks();
        }


        // Create an array adapter for the list view, using the Ipsum headlines array
        // setListAdapter(new ArrayAdapter<String>(getActivity(), layout, Ipsum.Headlines));
        displayListView();
        setListAdapter(dataAdapter);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.time_tile_list, container, false);




        // Inflate the layout for this fragment
        return rootView;

    }

    public void displayListView(){
        Cursor cursor = dbHelper.fetchAllTasks();

        String [] columns =  new String []{

                TimeActivityDbAdapter.KEY_TITLE

        };

        int[] to = new int [] {
                R.id.titleHeadline

        };

        dataAdapter = new SimpleCursorAdapter(getActivity(),
                R.layout.time_tile_list,
                cursor,
                columns,
                to,
                0);

       // ListView listView = (ListView)rootView.findViewById(R.id.titleHeadline);

    }

    @Override
    public void onStart() {
        super.onStart();

        // When in two-pane layout, set the listview to highlight the selected list item
        // (We do this during onStart because at the point the listview is available.)
        //**********************************************************************************
        if (getFragmentManager().findFragmentById(R.id.time_activity_fragment_container) != null) { //??%%&&  id
            getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        }


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            mCallback = (OnHeadlineSelectedListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // Notify the parent activity of selected item
        mCallback.onTaskSelected(id);

        // Set the item as checked to be highlighted when in two-pane layout
        getListView().setItemChecked(position, true);
    }
    @Override
    public void onCreateOptionsMenu(Menu menu,MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.time_activity_fragment_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

//        if (id == R.id.time_avtivity_instruction) {
//            go(TimeIntroductionFragment.class);
//        }


        switch (id) {
            case R.id.time_activity_menu_add:
               mCallback.onAddnewButtonClicked();
                break;
          
            case R.id.time_activity_instruction:
                mCallback.onGetHelpClicked();

            break;
            case R.id.time_activity_menu_summary:
                mCallback.onSummaryButtonClicked();

                break;        }

        return super.onOptionsItemSelected(item);
    }
}
