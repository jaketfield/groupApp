package com.example.tgk.integrationwithfragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.tgk.integrationwithfragment.R;

public class TimeIntroductionFragment extends Fragment {



    View rootView;
    TimeHeadlineFragment.OnHeadlineSelectedListener aCallback;

    public TimeIntroductionFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.time_introduction_window, container, false);
        setHasOptionsMenu(true);
        // If activity recreated (such as from screen rotate), restore
        // the previous article selection set by onSaveInstanceState().
        // This is primarily necessary when in the two-pane layout.

        return rootView;

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof TimeHeadlineFragment.OnHeadlineSelectedListener) {
            aCallback= (TimeHeadlineFragment.OnHeadlineSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }

//    public void updateTaskView(long id){
//        dbHelper = new TimeActivityDbAdapter(getActivity());//??????
//        dbHelper.open(); //!!!!!!!!!!!!!!!
//        Cursor cursor = dbHelper.fetchTasksByRowId(id);
//        TextView title = (TextView) getActivity().findViewById(R.id.title);
//        title.setText(cursor.getString(cursor.getColumnIndexOrThrow("title")));
//
//        TextView category = (TextView) getActivity().findViewById(R.id.category);
//        title.setText(cursor.getString(cursor.getColumnIndexOrThrow("category")));
//
//        TextView note = (TextView) getActivity().findViewById(R.id.note);
//        title.setText(cursor.getString(cursor.getColumnIndexOrThrow("note")));
//
//        TextView duration = (TextView) getActivity().findViewById(R.id.duration);
//        title.setText(cursor.getString(cursor.getColumnIndexOrThrow("duration")));
//
//        TextView date = (TextView) getActivity().findViewById(R.id.date);
//        title.setText(cursor.getString(cursor.getColumnIndexOrThrow("dateCreated")));
//
//    }

//    @Override
//    public void onSaveInstanceState(Bundle outState) {
//        super.onSaveInstanceState(outState);
//
//        // Save the current article selection in case we need to recreate the fragment
//        outState.putLong(ARG_POSITION, arowId);
//    }

    @Override
    public void onDetach() {
        super.onDetach();
        aCallback = null;
    }



    public void onCreateOptionsMenu(Menu menu,MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.time_activity_fragment_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

//        if (id == R.id.time_avtivity_instruction) {
//            go(TimeIntroductionFragment.class);
//        }


        switch (id) {
            case R.id.time_activity_menu_add:
                aCallback.onAddnewButtonClicked();
                break;

            case R.id.time_activity_instruction:
                aCallback.onGetHelpClicked();
                break;

            case R.id.time_activity_menu_summary:
                aCallback.onSummaryButtonClicked();

                break;        }

        return super.onOptionsItemSelected(item);
}


}
