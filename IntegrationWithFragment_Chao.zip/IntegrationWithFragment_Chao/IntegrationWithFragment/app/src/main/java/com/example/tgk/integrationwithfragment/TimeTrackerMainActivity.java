package com.example.tgk.integrationwithfragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

public class TimeTrackerMainActivity extends AppCompatActivity implements
        TimeHeadlineFragment.OnHeadlineSelectedListener {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);





//            // In case this activity was started with special instructions from an Intent,
//            // pass the Intent's extras to the fragment as arguments
//            introductionFragment.setArguments(getIntent().getExtras());

            // Add the fragment to the 'fragment_container' FrameLayout
        TimeHeadlineFragment headlineFragment=new TimeHeadlineFragment();
        FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.time_activity_fragment_container,headlineFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

//        TimeAddTaskFragment timeAddTaskFragment = new TimeAddTaskFragment();
//            getSupportFragmentManager().beginTransaction()
//                    .add(R.id.fragment_window, timeAddTaskFragment).commit();


    }

    @Override
    public void onAddnewButtonClicked() {
        // The user selected the headline of an article from the HeadlinesFragment

        // Capture the article fragment from the activity layout

        // If the frag is not available, we're in the one-pane layout and must swap frags...

        // Create fragment and give it an argument for the selected article
        TimeAddTaskFragment addnew = new TimeAddTaskFragment();

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, addnew);
        //
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
    @Override
    public void onDoneButtonClicked() {
        TimeIntroductionFragment timeIntroductionFragment = new TimeIntroductionFragment();
        Bundle args = new Bundle();
        timeIntroductionFragment.setArguments(args);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, timeIntroductionFragment);
        //
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
    @Override
    public void onViewButtonClicked() {
        TimeHeadlineFragment viewTask = new TimeHeadlineFragment();
        Bundle args = new Bundle();
        viewTask.setArguments(args);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, viewTask);
        //
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
    @Override
    public void onSummaryButtonClicked() {

        TimeTaskSummaryFragment timeTaskSummaryFragment = new TimeTaskSummaryFragment();
        Bundle args = new Bundle();
        timeTaskSummaryFragment.setArguments(args);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, timeTaskSummaryFragment);
        //
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
    @Override
    public void onBackToListButtonClicked() {
        // The user selected the headline of an article from the HeadlinesFragment

        // Capture the article fragment from the activity layout

        // If the frag is not available, we're in the one-pane layout and must swap frags...

        // Create fragment and give it an argument for the selected article
        TimeHeadlineFragment titleList = new TimeHeadlineFragment();
        Bundle args = new Bundle();
        titleList.setArguments(args);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, titleList);
        //
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
    @Override
    public void onTaskSelected(long id) {
        // The user selected the headline of an article from the HeadlinesFragment

        // Capture the article fragment from the activity layout
//            TaskDetailsFragment taskDetailsFragment = (TaskDetailsFragment)
//                getSupportFragmentManager().findFragmentById(R.id.fragment_window);//******************

//        if (taskDetailsFragment != null) {
//            // If article frag is available, we're in two-pane layout...
//
//            // Call a method in the ArticleFragment to update its content
//            taskDetailsFragment.updateTaskView(id);
//
//        } else {
            // If the frag is not available, we're in the one-pane layout and must swap frags...

            // Create fragment and give it an argument for the selected article
            TaskDetailsFragment newFragment = new TaskDetailsFragment();

            Bundle args = new Bundle();
            args.putLong(TaskDetailsFragment.ARG_POSITION, id);
            newFragment.setArguments(args);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            // Replace whatever is in the fragment_container view with this fragment,
            // and add the transaction to the back stack so the user can navigate back
            transaction.replace(R.id.time_activity_fragment_container, newFragment);
            transaction.addToBackStack(null);

            // Commit the transaction
            transaction.commit();
        }
    //}
    @Override
    public void onSubmitButtonClicked(){

        TimeHeadlineFragment timeHeadlineFragment = new TimeHeadlineFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, timeHeadlineFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

//        if (id == R.id.time_avtivity_instruction) {
//            go(TimeIntroductionFragment.class);
//        }


        switch (id) {
            case R.id.action_one:
                go(FootprintActivity.class);
                break;
            case R.id.action_two:
                go(TimeTrackerMainActivity.class);
                break;
            case R.id.action_three:
                //go(FootprintActivity.class);
                break;
            case R.id.action_four:
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    private void go(Class c) {
        Intent intent = new Intent(this, c);
        startActivity(intent);
    }
@Override
    public void onGetHelpClicked(){
        TimeIntroductionFragment timeIntroductionFragment= new TimeIntroductionFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, timeIntroductionFragment);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();
    }

}
