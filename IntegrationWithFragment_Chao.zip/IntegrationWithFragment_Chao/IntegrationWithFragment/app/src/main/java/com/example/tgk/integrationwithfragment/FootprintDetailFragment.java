package com.example.tgk.integrationwithfragment;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Xuejian on 2016-04-12.
 */
public class FootprintDetailFragment extends Fragment {
    public static final String ARG_ID = "ROWID";
    private FootprintDbAdapter dbHelper;
    private Button okButton = null;
    private Button deleteButton = null;
    private Button summaryButton = null;
    TripRecord tripRecord = new TripRecord();
    OnFootprintListener mCallBack;
    Long id;

    int mCurrentId = -1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View fragmentView = inflater.inflate(R.layout.footprint_detail_fragment, container, false);
        if (savedInstanceState != null) {
            id = savedInstanceState.getLong(ARG_ID);
        }

        okButton = (Button)fragmentView.findViewById(R.id.footdetail_ok);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mCallBack.onBtnClick(v, null);
            }
        });

        deleteButton = (Button)fragmentView.findViewById(R.id.footdetail_delete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mCallBack.onBtnClick(v, tripRecord);
            }
        });

        summaryButton = (Button)fragmentView.findViewById(R.id.footdetail_summary_btn);
        summaryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                mCallBack.onBtnClick(v, tripRecord);
            }
        });
        return fragmentView;
    }


    @Override
    public void onStart() {
        super.onStart();
        Bundle args = getArguments();
        if (args != null) {
            // Set article based on argument passed in
            updateItemView(args.getLong(ARG_ID));
        } else if (mCurrentId != -1) {
            // Set article based on saved instance state defined during onCreateView
            updateItemView(mCurrentId);
        }
    }

    public void updateItemView(long id) {
        dbHelper= new FootprintDbAdapter(getActivity());
        dbHelper.open();
        Cursor cursor = dbHelper.fetchRecordById(id);

        tripRecord.setCategory(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_CATEGORY)));
        tripRecord.setVehicleType(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_VEHICLETYPE)));
        tripRecord.setDistance(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_DISTANCE)));
        tripRecord.setDate(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_DATE)));
        tripRecord.setNote(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_NOTE)));

        TextView categoryView = (TextView) getView().findViewById(R.id.footprint_category);
        categoryView.setText(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_CATEGORY)));

        TextView vehicleTypeView = (TextView) getView().findViewById(R.id.footprint_vechile_type);
        vehicleTypeView.setText(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_VEHICLETYPE)));

        TextView distanceView = (TextView) getView().findViewById(R.id.footprint_distance);
        distanceView.setText(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_DISTANCE)));

        TextView dateView = (TextView) getView().findViewById(R.id.footprint_date);
        dateView.setText(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_DATE)));

        TextView noteView = (TextView) getView().findViewById(R.id.footprint_note);
        noteView.setText(cursor.getString(cursor.getColumnIndex(FootprintDbAdapter.KEY_NOTE)));
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mCallBack = (OnFootprintListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFootprintListener");
        }
    }
}





